#include <iostream>
using namespace std;

void mirrorFunc()
{
	cout << "I am the best" << endl;
}
void Voice()
{
	cout << "You hear my voice from new_branch" << endl;
}

int main()
{
	mirrorFunc();
	Voice();
	return 0;
}
