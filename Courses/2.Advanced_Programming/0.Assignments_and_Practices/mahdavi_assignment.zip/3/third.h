#ifndef ThIRD_H
#define THIRD_H

#include <iostream>
#include <stdexcept>
using namespace std;

class CF3 : public runtime_error{
    public:
    CF3(string what = "runtime error occurd.");
};

void f1(int * s, int size);

#endif
