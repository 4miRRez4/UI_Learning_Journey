#include "third.h"

CF3::CF3(string what) : runtime_error(what) {};

void f1(int * s, int size){
    for(int i=0; i<size; i++){
        if(s[i] < 0 || s[i] > 20){
            delete[] s;
            throw CF3("general exception occurred");
        }
        else
            cout << s[i] << " ";
    }
    delete[] s;
}

int main(){
    int* myArr = new int[3];
    myArr[0] = 21;
    myArr[1] = 2;
    myArr[2] = 3;
    try{
        f1(myArr, 3);
    }catch(CF3& exc){
        cout << exc.what() << endl;
    }
    return 0;
}