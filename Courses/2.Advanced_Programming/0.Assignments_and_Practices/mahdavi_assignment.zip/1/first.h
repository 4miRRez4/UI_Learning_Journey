#ifndef FIRST_H
#define FIRST_H

#include <iostream>
using namespace std;

class CF1{
    public:
    CF1();
    CF1(const string& str);
    private:
    string s;
};



#endif