#include "first.h"

CF1::CF1() {};

CF1::CF1(const string& str){
    this->s = str;
}

int main() {
    string mystr = "AP FINAL";
    CF1 obj;
    obj = mystr;

    return 0;
}
