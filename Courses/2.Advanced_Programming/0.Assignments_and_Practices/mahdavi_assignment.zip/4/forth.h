#ifndef FORTH_H
#define FORTH_H

#include <iostream>
#include <vector>
using namespace std;

class Polygon{
    public:
    virtual int get_area() const = 0;
    private:
    int num_of_azla;
};

class TwoDim : public Polygon{
    public:
    TwoDim(int a);
    TwoDim(const TwoDim& other);
    virtual int get_area() const;
    private:
    int area;
};

class TreeDim : public Polygon{
    public:
    TreeDim(int num, vector<TwoDim>& voj);
    virtual int get_area() const;
    private:
    int num_of_vojoh;
    vector<TwoDim> vojoh_vec;
};

class Rect : public TwoDim{
    public:
    Rect(int a);
};


#endif