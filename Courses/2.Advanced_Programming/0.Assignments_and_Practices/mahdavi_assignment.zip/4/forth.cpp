#include "forth.h"

TwoDim::TwoDim(int a) : area(a) {};

TwoDim::TwoDim(const TwoDim& other) {
    this->area = other.area;
}

int TwoDim::get_area() const {
    return this->area;
}

TreeDim::TreeDim(int num, vector<TwoDim>& voj) : num_of_vojoh(num), vojoh_vec(voj) {};

int TreeDim::get_area() const{
    int a = 0;
    for(int i=0; i<this->num_of_vojoh; i++)
        a += vojoh_vec[i].get_area();

    return a;
}

Rect::Rect(int a) : TwoDim(a) {};

int main(){
    Rect myRec1(10);
    Rect myRec2 = myRec1;
    Rect myRec3(30);
    Rect myRec4(40);
    Rect myRec5(50);
    Rect myRec6(60);

    vector<TwoDim> rectangles;
    rectangles.push_back(myRec1);
    rectangles.push_back(myRec2);
    rectangles.push_back(myRec3);
    rectangles.push_back(myRec4);
    rectangles.push_back(myRec5);
    rectangles.push_back(myRec6);

    TreeDim myTreeDim(6, rectangles);

    cout << "area of myRec1: " << myRec1.get_area() << endl;
    cout << "area of myTreedim: " << myTreeDim.get_area() << endl;
    return 0;
}