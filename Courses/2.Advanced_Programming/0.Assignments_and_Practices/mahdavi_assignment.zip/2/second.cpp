#include <iostream>
#include <vector>
#include <set>
using namespace std;

template<typename T>
vector<T> reverse_set_to_vector(set<T>& s){
    vector<T> v;
    auto setIt = s.rbegin();

    while(setIt != s.rend()){
        v.push_back(*setIt);
        setIt++;
    }
    
    return v;
}

int main(){
    set<int> myset = {1, 2, 3};
    vector<int> myvector = reverse_set_to_vector(myset);
    for(int i=0; i<myvector.size(); i++)
        cout << myvector[i] ;
    return 0;
}