#include <iostream>
using namespace std;

int main()
{
    int n; cin >> n;
    if(n%2 == 0)
    {
        cout << "hahaha nafare dovom bakht" << endl;
    }
    else
    {  
        cout << "HAHAHA nafare aval bakht" << endl;
    }

    return 0;
}